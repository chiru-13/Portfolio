# Colorful Theme Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/eYPYppR](https://codepen.io/jkantner/pen/eYPYppR).

A theme toggle switch that utilizes `:has()` to turn everything dark rather than the tiniest bit of JavaScript. `:has()` support in Firefox is still experimental as of this Pen, so don’t expect it to work well there.